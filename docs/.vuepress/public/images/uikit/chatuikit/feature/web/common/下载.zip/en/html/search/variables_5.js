var searchData=
[
  ['fail_0',['FAIL',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_status.html#adb4f4c86520adef2366098910ca2abc5',1,'io::agora::chat::ChatMessage::Status']]],
  ['failed_1',['FAILED',['../enumio_1_1agora_1_1chat_1_1_file_message_body_1_1_e_m_download_status.html#a5923d256b938bc06fb68c81315e48c64',1,'io::agora::chat::FileMessageBody::EMDownloadStatus']]],
  ['file_2',['FILE',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_type.html#a26bc63cd510366218b2d52c2492cf529',1,'io.agora.chat.ChatMessage.Type.FILE()'],['../enumio_1_1agora_1_1chat_1_1_chat_statistics_manager_1_1_search_message_type.html#afb3f2f1191e2d6e3f0af96d1ab28cf1a',1,'io.agora.chat.ChatStatisticsManager.SearchMessageType.FILE()']]],
  ['file_5fcontent_5fimproper_3',['FILE_CONTENT_IMPROPER',['../classio_1_1agora_1_1_error.html#ab383ea6243a4b445c6e87dcf21ec60cc',1,'io::agora::Error']]],
  ['file_5fdelete_5ffailed_4',['FILE_DELETE_FAILED',['../classio_1_1agora_1_1_error.html#af666abdc8fc0e80319d52b1736b2b4a0',1,'io::agora::Error']]],
  ['file_5fdownload_5ffailed_5',['FILE_DOWNLOAD_FAILED',['../classio_1_1agora_1_1_error.html#a4b7d819e049bcd06160b8ecd5cc221c3',1,'io::agora::Error']]],
  ['file_5finvalid_6',['FILE_INVALID',['../classio_1_1agora_1_1_error.html#a9cfeff5aedd067be1e39251c14dd8f2b',1,'io::agora::Error']]],
  ['file_5fis_5fexpired_7',['FILE_IS_EXPIRED',['../classio_1_1agora_1_1_error.html#ac726d63b383957aaa36ed06289b02c31',1,'io::agora::Error']]],
  ['file_5fnot_5ffound_8',['FILE_NOT_FOUND',['../classio_1_1agora_1_1_error.html#a38be6f1c6f5851c0ea1ecb55ac5590ac',1,'io::agora::Error']]],
  ['file_5ftoo_5flarge_9',['FILE_TOO_LARGE',['../classio_1_1agora_1_1_error.html#a085d29dfd0fc543a60a80c37fc935c73',1,'io::agora::Error']]],
  ['file_5fupload_5ffailed_10',['FILE_UPLOAD_FAILED',['../classio_1_1agora_1_1_error.html#a1b64a4002c8b16c7669209d7af9d63e7',1,'io::agora::Error']]]
];
