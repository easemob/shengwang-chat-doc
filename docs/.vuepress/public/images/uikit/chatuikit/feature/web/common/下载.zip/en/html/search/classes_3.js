var searchData=
[
  ['fetchmessageoption_0',['FetchMessageOption',['../classio_1_1agora_1_1chat_1_1_fetch_message_option.html',1,'io::agora::chat']]],
  ['filemessagebody_1',['FileMessageBody',['../classio_1_1agora_1_1chat_1_1_file_message_body.html',1,'io::agora::chat']]]
];
