var searchData=
[
  ['textmessagebody_0',['TextMessageBody',['../classio_1_1agora_1_1chat_1_1_text_message_body.html#aca249d7a9b835345ba1b82b76fba9fa4',1,'io::agora::chat::TextMessageBody']]],
  ['thumbnaildownloadstatus_1',['thumbnailDownloadStatus',['../classio_1_1agora_1_1chat_1_1_image_message_body.html#a8fb7d34d2709c61e7248a076b1d1d3c1',1,'io.agora.chat.ImageMessageBody.thumbnailDownloadStatus()'],['../classio_1_1agora_1_1chat_1_1_video_message_body.html#a7309333879a344db55b63543724f9a37',1,'io.agora.chat.VideoMessageBody.thumbnailDownloadStatus()']]],
  ['thumbnaillocalpath_2',['thumbnailLocalPath',['../classio_1_1agora_1_1chat_1_1_image_message_body.html#a26bc1ce0669d03daf28dbad93b565e68',1,'io::agora::chat::ImageMessageBody']]],
  ['thumbnaillocaluri_3',['thumbnailLocalUri',['../classio_1_1agora_1_1chat_1_1_image_message_body.html#a008c6d000a07ec8d019506590e132f32',1,'io::agora::chat::ImageMessageBody']]],
  ['tostring_4',['toString',['../classio_1_1agora_1_1chat_1_1_chat_thread.html#aeb1c9aecbc147c4b45b4880a15e6efa7',1,'io.agora.chat.ChatThread.toString()'],['../classio_1_1agora_1_1chat_1_1_cmd_message_body.html#abbc1cf82b9bd1b1659c5a7a4dd660c85',1,'io.agora.chat.CmdMessageBody.toString()'],['../classio_1_1agora_1_1chat_1_1_group.html#af197dae812e5f8f424e28c7d380c9395',1,'io.agora.chat.Group.toString()']]],
  ['translatemessage_5',['translateMessage',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a978494fa3f1d98e828b286e72c2e1ceb',1,'io::agora::chat::ChatManager']]]
];
