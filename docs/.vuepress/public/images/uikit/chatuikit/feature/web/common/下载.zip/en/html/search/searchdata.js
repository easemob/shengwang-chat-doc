var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuv",
  1: "cdefgilmnoprstuv",
  2: "abcdefgijklmnoprstuv",
  3: "abcdefghilmnopqrstuv",
  4: "cdm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

