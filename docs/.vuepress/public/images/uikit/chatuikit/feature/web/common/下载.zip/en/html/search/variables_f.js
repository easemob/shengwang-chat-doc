var searchData=
[
  ['reaction_5fhas_5fbeen_5foperated_0',['REACTION_HAS_BEEN_OPERATED',['../classio_1_1agora_1_1_error.html#a4fb372bc4d1b27a5c3b1f281585144b8',1,'io::agora::Error']]],
  ['reaction_5foperation_5fis_5fillegal_1',['REACTION_OPERATION_IS_ILLEGAL',['../classio_1_1agora_1_1_error.html#ae692158faed6fb60eef2418c1d76997c',1,'io::agora::Error']]],
  ['reaction_5freach_5flimit_2',['REACTION_REACH_LIMIT',['../classio_1_1agora_1_1_error.html#abf40b8706d07a0f24f7fd4ebf3d08a08',1,'io::agora::Error']]],
  ['receive_3',['RECEIVE',['../enumio_1_1agora_1_1chat_1_1_chat_statistics_manager_1_1_search_message_direct.html#a451b03859fde5e52385056971ac9b0ef',1,'io::agora::chat::ChatStatisticsManager::SearchMessageDirect']]],
  ['remind_5ftype_4',['REMIND_TYPE',['../enumio_1_1agora_1_1chat_1_1_silent_mode_param_1_1_silent_mode_param_type.html#a3ed53fd1714e196d1bc5f439a7568214',1,'io::agora::chat::SilentModeParam::SilentModeParamType']]]
];
