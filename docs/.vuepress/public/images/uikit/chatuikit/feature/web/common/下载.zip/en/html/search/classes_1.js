var searchData=
[
  ['deviceinfo_0',['DeviceInfo',['../classio_1_1agora_1_1chat_1_1_device_info.html',1,'io::agora::chat']]],
  ['direct_1',['Direct',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_direct.html',1,'io::agora::chat::ChatMessage']]],
  ['displaystyle_2',['DisplayStyle',['../enumio_1_1agora_1_1chat_1_1_push_manager_1_1_display_style.html',1,'io::agora::chat::PushManager']]]
];
