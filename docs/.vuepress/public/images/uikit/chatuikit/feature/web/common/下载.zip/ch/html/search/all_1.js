var searchData=
[
  ['mainpage_0',['mainpage',['../md___users_xuchengpu__desktop_test_agora_emclient_android_mainpage.html',1,'']]],
  ['multidevicelistener_1',['MultiDeviceListener',['../interfaceio_1_1agora_1_1_multi_device_listener.html',1,'io::agora']]]
];
