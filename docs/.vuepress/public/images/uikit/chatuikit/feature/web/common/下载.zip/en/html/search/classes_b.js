var searchData=
[
  ['resultcallback_0',['ResultCallBack',['../interfaceio_1_1agora_1_1_result_call_back.html',1,'io::agora']]]
];
