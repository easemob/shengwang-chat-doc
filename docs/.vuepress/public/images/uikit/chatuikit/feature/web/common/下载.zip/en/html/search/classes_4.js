var searchData=
[
  ['group_0',['Group',['../classio_1_1agora_1_1chat_1_1_group.html',1,'io::agora::chat']]],
  ['groupchangelistener_1',['GroupChangeListener',['../interfaceio_1_1agora_1_1_group_change_listener.html',1,'io::agora']]],
  ['groupinfo_2',['GroupInfo',['../classio_1_1agora_1_1chat_1_1_group_info.html',1,'io::agora::chat']]],
  ['groupmanager_3',['GroupManager',['../classio_1_1agora_1_1chat_1_1_group_manager.html',1,'io::agora::chat']]],
  ['groupoptions_4',['GroupOptions',['../classio_1_1agora_1_1chat_1_1_group_options.html',1,'io::agora::chat']]],
  ['grouppermissiontype_5',['GroupPermissionType',['../enumio_1_1agora_1_1chat_1_1_group_1_1_group_permission_type.html',1,'io::agora::chat::Group']]],
  ['groupreadack_6',['GroupReadAck',['../classio_1_1agora_1_1chat_1_1_group_read_ack.html',1,'io::agora::chat']]],
  ['groupstyle_7',['GroupStyle',['../enumio_1_1agora_1_1chat_1_1_group_manager_1_1_group_style.html',1,'io::agora::chat::GroupManager']]]
];
