var searchData=
[
  ['be_5fkicked_0',['BE_KICKED',['../interfaceio_1_1agora_1_1_chat_room_change_listener.html#ab33aa3e17830603437abd43f81378de5',1,'io::agora::ChatRoomChangeListener']]],
  ['be_5fkicked_5ffor_5foffline_1',['BE_KICKED_FOR_OFFLINE',['../interfaceio_1_1agora_1_1_chat_room_change_listener.html#a008f80b599b824246cb0415a126a251f',1,'io::agora::ChatRoomChangeListener']]],
  ['binddevicetoken_2',['bindDeviceToken',['../classio_1_1agora_1_1chat_1_1_push_manager.html#ab30d1b2bbbd72d9ad298aab8c7e394ea',1,'io::agora::chat::PushManager']]],
  ['blockchatroommembers_3',['blockChatroomMembers',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a73edbedeaa74a3707e6fceefe4b50d2b',1,'io::agora::chat::ChatRoomManager']]],
  ['blockgroupmessage_4',['blockGroupMessage',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a3488560e515cc783c12d04f7b3377d99',1,'io::agora::chat::GroupManager']]],
  ['blockuser_5',['blockUser',['../classio_1_1agora_1_1chat_1_1_group_manager.html#aaa37498c8c6eb2e6d4bee059b6830606',1,'io::agora::chat::GroupManager']]],
  ['blockusers_6',['blockUsers',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a30b37f13386fd7369e37377538f441dc',1,'io::agora::chat::GroupManager']]]
];
