var searchData=
[
  ['partial_5fsuccess_0',['PARTIAL_SUCCESS',['../classio_1_1agora_1_1_error.html#a74ed1edfad8786db7d3ad08bfc467eda',1,'io::agora::Error']]],
  ['pending_1',['PENDING',['../enumio_1_1agora_1_1chat_1_1_file_message_body_1_1_e_m_download_status.html#a90bc3ed1899dc16fe21cf841299f8590',1,'io::agora::chat::FileMessageBody::EMDownloadStatus']]],
  ['presence_5fcannot_5fsubscribe_5fyourself_2',['PRESENCE_CANNOT_SUBSCRIBE_YOURSELF',['../classio_1_1agora_1_1_error.html#aec5c47a237ae043134ed9cf98833dac9',1,'io::agora::Error']]],
  ['presence_5fparam_5flength_5fexceed_3',['PRESENCE_PARAM_LENGTH_EXCEED',['../classio_1_1agora_1_1_error.html#a8e36e17cebada314329869c15c8c9a14',1,'io::agora::Error']]],
  ['push_5fbind_5ffailed_4',['PUSH_BIND_FAILED',['../classio_1_1agora_1_1_error.html#a82cce9d58328edf6556cb47cca529578',1,'io::agora::Error']]],
  ['push_5fnot_5fsupport_5',['PUSH_NOT_SUPPORT',['../classio_1_1agora_1_1_error.html#a52fbf1edabb1cd227d80de0a4207be1a',1,'io::agora::Error']]],
  ['push_5freport_5faction_5ffailed_6',['PUSH_REPORT_ACTION_FAILED',['../classio_1_1agora_1_1_error.html#ac7ba25ceb164950d3b6593baeb708580',1,'io::agora::Error']]],
  ['push_5funbind_5ffailed_7',['PUSH_UNBIND_FAILED',['../classio_1_1agora_1_1_error.html#ae79a4f0bf3b15d273d89eff3d7095390',1,'io::agora::Error']]]
];
