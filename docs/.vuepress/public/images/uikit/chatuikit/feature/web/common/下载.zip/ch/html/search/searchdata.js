var indexSectionsWithContent =
{
  0: "cm即",
  1: "cm",
  2: "m即"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "页"
};

