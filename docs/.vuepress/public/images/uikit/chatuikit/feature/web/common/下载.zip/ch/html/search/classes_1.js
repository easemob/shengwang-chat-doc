var searchData=
[
  ['multidevicelistener_0',['MultiDeviceListener',['../interfaceio_1_1agora_1_1_multi_device_listener.html',1,'io::agora']]]
];
